document.querySelector('button')addEventListener('click', () => 
{
    
})